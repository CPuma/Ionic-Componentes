### INSTALAR CARPETA PARA CERTIFICACIONES
### CREAR CARPETA certificaciones en /var/www
`mkdir /var/www/certificaciones`  
`chmod 777 -R /var/www/certificaciones`  
### DESCOMENTAR LAS LINEAS DE CERTIFICACIONES EN default-ssl
`vi /etc/nginx/sites-available/default-ssl`  
### REINICIAR PHP Y NGINX
`service php7.0-fpm restart`  
`service nginx restart`  
### INGRESAR DESDE LA SIGUIENTE URL
`https://legalprodata.com/certificaciones`  
### INSTALAR MOODLE
### DESCARGAR MOODLE
`cd /var/www`  
`wget https://download.moodle.org/download.php/direct/stable34/moodle-3.4.tgz`  
`tar -xzvf moodle-3.4.tgz`  
`mv moodle aulavirtual`  
### CREAR CARPETA DONDE SE GUARDARA LA DATA
`mkdir /var/www/aulavirtualdata`  
`chmod 777 -R /var/www/aulavirtualdata`  
### RUTA PARA LA DATA
`/var/www/aulavirtualdata`  
### CREAR LA BASE DE DATOS Y EL USUARIO DE AULAVIRTUAL
`mysql --defaults-file=/etc/mysql/newt.cnf`  
`create database aulavirtual;`  
`CREATE USER 'aulavirtual'@'%' IDENTIFIED BY 'aulavirtual';`  
`GRANT ALL PRIVILEGES ON aulavirtual.* TO 'aulavirtual'@'%';`  
`FLUSH PRIVILEGES;`  
`EXIT;`  
### MODIFICAR security.limit_extensions = .php EN LINEA 380
`vi /etc/php/7.0/fpm/pool.d/www.conf`  # security.limit_extensions = .php  
### COPIAR aulavirtual a /etc/nginx/sites-available/
### CREAR ENLACE SIMBOLICO
`ln -s /etc/nginx/sites-available/aulavirtual /etc/nginx/sites-enabled/aulavirtual`  
### CONFIGURAR CERTIFICADO CON CERBOT Y SSL LETS ENCRYPT
### AGREGAR UN REPOSITORIO A SOURCE
`vi /etc/apt/sources.list`  
`deb http://ftp.debian.org/debian jessie-backports main`  
`aptitude update`  
`apt-get install certbot -t jessie-backports`  
`aptitude install nginx`  
`certbot certonly -a webroot --webroot-path=/var/www/aulavirtual -d aulavirtual.legalprodata.com`  
### RUTA DONDE ESTAN LOS ENLACES DE CERTIFICADOS
```
cd /etc/letsencrypt/live/aulavirtual.legalprodata.com/
ls
```
### RUTA DONDE ESTAN LOS CERTIFICADOS VERDADEROS
```
cd /etc/letsencrypt/archive/aulavirtual.legalprodata.com/
ls
```
### CREAR ENLACE SIMBOLICO PARA LOS CERTIFICADOS
`ln -s /etc/letsencrypt/live/aulavirtual.legalprodata.com/fullchain.pem /etc/ssl/certs/aulavirtual.legalprodata.com.crt`  
`ln -s /etc/letsencrypt/live/aulavirtual.legalprodata.com/privkey.pem /etc/ssl/private/aulavirtual.legalprodata.com.key`  
`cd /etc/ssl`  
`openssl x509 -subject -fingerprint -noout -in certs/aulavirtual.legalprodata.com.crt`  
`chmod 400 certs/aulavirtual.legalprodata.com.crt private/aulavirtual.legalprodata.com.key`  
### REINICIAR PHP Y NGINX
```
service php7.0-fpm restart
service nginx restart
```
### INGRESAR A INSTALAR MOODLE
`aptitude install php7.0-curl php7.0-zip php7.0-gd php7.0-soap php7.0-xmlrpc`  
`chmod 777 -R /var/www/aulavirtual`  
`https://aulavirtual.legalprodata.com/install.php`  
### DIRECTORIO DE DATOS
`/var/www/aulavirtualdata`  
### DATOS DE LA CONEXION A MARIADB
```
host de la Base de Datos : newtmaria.csdlywkzvt6k.us-east-1.rds.amazonaws.com
Nombre de la base de datos: aulavirtual
Usuario de la base de datos: aulavirtual
Contraseña de la base de datos: aulavirtual
Prefijo de tablas: aulavirtual_

```
### INSTALAR MYADMIN
### DESCARGAR MYADMIN
`aptitude install unzip php7.0-bz2`  
`cd /var/www`  
`wget https://files.phpmyadmin.net/phpMyAdmin/4.7.9/phpMyAdmin-4.7.9-all-languages.zip`  
`unzip phpMyAdmin-4.7.9-all-languages.zip`  
`mv phpMyAdmin-4.7.9-all-languages riccadonna`  
`chmod 777 -R /var/www/riccadonna`  
### DESCOMENTAR LAS LINEAS DE PHP
### REINICIAR PHP Y NGING
```
service php7.0-fpm restart
service nginx restart
```
### INGRESAR A LA WEB
`https://legalprodata.com/riccadonna/setup/`  
```
Poner nuevo servidor
Nombre del servidor, forma extendida: Peritum
Nombre del servidor: newtmaria.csdlywkzvt6k.us-east-1.rds.amazonaws.com
```
### ARCHIVO DE CONFIGURACION
```
Idioma predeterminado: Español-Spanish
Servidor predeterminado: Peritum[1]
Final de la lína: UNIX / Linux (\n)
```
### DESCARGAR EL ARCHIVO
### COPIAR TODO EL CONTENIDO DEL ARCHIVO AL SIGUIENTE FICHERO CREADO
`nano /var/www/riccadonna/config.inc.php`
### CONECTARSE AL ADMINISTRADOR
`https://legalprodata.com/riccadonna`  
### ELIMINAR LA CARPETA DE SETUP
`rm /var/www/riccadonna/setup -R`  

### INSTALAR SERVIDOR DE WORPRESS
### MODIFICAR REPOSITORIO
`vi /etc/apt/sources.list`  
### ACTUALIZAR SISTEMA
`apt-get update`  
`apt-get install aptitude`  
`aptitude update`  
`aptitude upgrade`  
`reboot`  
### RECONFIGURAR VIM
`vi /etc/vim/vimrc`  
`update-alternatives --config editor` #seleccionar vim.basic  
### COMENTAR LAS LINEAS DEL SIGUIENTE ARCHIVO SI ES NECESARIO
`vi /usr/share/vim/vim80/defaults.vim`  
### DEBE QUEDAR ASI
```
" In many terminal emulators the mouse works just fine.  By enabling it you
" can position the cursor, Visually select and scroll with the mouse.
"if has('mouse')
"  set mouse=a
"endif
```
### VER CUANTO DISCO DURO OCUPA LOS PAQUETES
`du -sh /var/cache/apt/archives`  
### BORRAR LOS PAQUETES DE ACTUALIZACION
`aptitude clean`  
### RECONFIGURAR DIA Y HORA
`dpkg-reconfigure tzdata`  
### LIBERAR MEMORIA CADA 5 MINUTOS EN CRON
`aptitude install sudo`  
`cd /home`  
`vi liberar.sh`  
```shell
### LIBERAR MEMORIA
sudo sync && sudo sysctl -w vm.drop_caches=3
```
`chmod 777 liberar.sh`  
### CREAR TAREA QUE SE EJECUTAR CADA HORA
`crontab -e`  
### NO MANDAR CORREO DEL RESULTADO DEL CRON
`MAILTO=""`  
### SI SALE PARA SELECCIONAR EDITOR ESCOGER vim.basic
### EJECUTAR CADA 5 MINUTOS
`*/5 * * * * bash /home/liberar.sh`  
### EJECUTAR CADA HORA
`0 * * * * bash /home/liberar.sh`  
### CREAR BASE DE DATOS EN RDS
### US East (N. Virginia) us-east-1
`Seleccionar Only enable options elegible for RDS Free Usage Tier Info`  
### SELECCIONAR MARIADB
### DISCO DURO
`20GB`  
### CONFIGURACION DE LA BASE DE DATOS
```
DB Instance Identifier*: newt
Master Username*: root
Master Password*: mypeserver
Confirm Password*: mypeserver
```
### CONFIGURACIONES AVANZADAS
```
VPC*: newt-vpc
Subnet Group: Create new DB Subnet Group
Publicly Accessible: No
Availability Zone: us-east-1a
VPC Security Group(s): default (VPC)
Database Name: newt
```
### LUEGO DE CREAR EL SERVIDOR ENTRAR A SECURITY GROUPS Y MODIFICAR ACCESO
`https://console.aws.amazon.com/ec2/v2/home?region=us-east-1#SecurityGroups`  
### ESCOGER EL GRUPO CREADO POR RDS
`rds-launch-wizard->Inbound Rules -> Edit`  
```
Type : All traffic
Protocol : All
Port range :  ALL
Source : 0.0.0.0/0  
```
### INSTALAR CLIENTE MYSQL PARA CONECTARSE A RDS
`aptitude install mysql-client`  
### PROBAR CONEXION
`mysql -u root -p -h newt.cavb1vdbmmgn.us-east-1.rds.amazonaws.com`  
### CONFIGURAR CERTIFICADO SSL COMPRADO EN NAMECHEAP
### CREAR UNA CLAVE PRIVADA EN NUESTRO SERVIDOR Y CREAMOS UN CERTIFICATE SIGNING REQUEST(CSR) 
### PARA SOLICITAR NUESTRO CERTIFICADO SSL A UNA ENTIDAD DE AUTORIZACIÓN RECONOCIDA
`cd /etc/ssl`  
`openssl req -new -newkey rsa:2048 -nodes -keyout private/legalprodata.com.key -out legalprodata.com.csr`  
### RESPONDER LOS DATOS SOLICITADOS
```
Country Name (2 letter code) [AU]:PE
State or Province Name (full name) [Some-State]:Lima
Locality Name (eg, city) []:Lima
Organization Name (eg, company) [Internet Widgits Pty Ltd]:Peritum
Organizational Unit Name (eg, section) []:TI
Common Name (e.g. server FQDN or YOUR name) []:legalprodata.com
Email Address []:hola@legalprodata.com
Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []: Peritum
```
### SEGUIR TODOS LOS PASOS EN LA WEB HASTA OBTENER EL ARCHIVO .crt Y .ca-bundle
`cat legalprodata.com.csr`  
`mkdir /home/ssl`  
`chmod 777 -R /home/ssl`  
### SUBIR EL ARCHIVO .crt Y .ca-bundle A /home/ssl
`cd /home/ssl`  
`cat newt_pe.crt newt_pe.ca-bundle >> legalprodata.com.crt`  
`cp legalprodata.com.crt /etc/ssl/certs/`  
`rm legalprodata.com.crt`  
`rm newt_pe.crt`  
`rm newt_pe.ca-bundle`  
`cd /etc/ssl`  
`openssl x509 -subject -fingerprint -noout -in certs/legalprodata.com.crt`  
`chmod 400 certs/legalprodata.com.crt private/legalprodata.com.key`  
`rm /home/ssl -R`  
### INSTALAR NGINX
`aptitude install nginx`  
### CONFIGURAR SITIO SSL EN NGINX
### DETENER NGINX
`service nginx stop`  
### CONFIGURAR CERTIFICADO CON CERBOT Y SSL LETS ENCRYPT
`aptitude install certbot`  
`aptitude install nginx`  
`certbot certonly -a webroot --webroot-path=/var/www/html -d tienda.legalprodata.com`  
### RUTA DONDE ESTAN LOS ENLACES DE CERTIFICADOS
`cd /etc/letsencrypt/live/tienda.legalprodata.com/`  
`ls`  
### RUTA DONDE ESTAN LOS CERTIFICADOS VERDADEROS
`cd /etc/letsencrypt/archive/tienda.legalprodata.com/`  
`ls`  
### CREAR ENLACE SIMBOLICO PARA LOS CERTIFICADOS
`ln -s /etc/letsencrypt/live/tienda.legalprodata.com/fullchain.pem /etc/ssl/certs/legalprodata.com.crt`  
`ln -s /etc/letsencrypt/live/tienda.legalprodata.com/privkey.pem /etc/ssl/private/legalprodata.com.key`  
`cd /etc/ssl`  
`openssl x509 -subject -fingerprint -noout -in certs/legalprodata.com.crt`  
`chmod 400 certs/legalprodata.com.crt private/legalprodata.com.key`  
### INSTALAR NGINX
`aptitude install nginx`  
### CONFIGURAR SITIO SSL EN NGINX
### DETENER NGINX
`service nginx stop`  
### COPIAR default-ssl a /etc/nginx/sites-available/
### ELIMINAR SITIO POR DEFECTO
`rm /etc/nginx/sites-available/default`  
`rm /etc/nginx/sites-enabled/default`  
### CREAR ENLACE SIMBOLICO
`ln -s /etc/nginx/sites-available/default-ssl /etc/nginx/sites-enabled/default-ssl`  
### INICIAR NGINX
`service nginx start  `
### INSTALAR PHP7
### BUSCAR PAQUETES DE PHP7
`apt-cache search php7.0-\*`  
`aptitude install php7.0-fpm php7.0-mysql php7.0-xml`  
### MODIFICAR cgi.fix_pathinfo=0 EN LINEA 760
`vi /etc/php/7.0/fpm/php.ini` # cgi.fix_pathinfo=0  
### MODIFICAR HORA EN PHP7 EN LINEA 924
`vi /etc/php/7.0/fpm/php.ini` # date.timezone = 'America/Lima'
### MODIFICAR EL SITIO NGINX PARA QUE ACEPTE PHP
`vi /etc/nginx/sites-available/default-ssl`  
### DESCOMENTAR LAS LINEAS DE PHP
### REINICIAR PHP Y NGING
```
service php7.0-fpm restart
service nginx restart
```
### CREAR CADENA DE CONEXION PARA USAR SIEMPRE
`vi /etc/mysql/newt.cnf`  
```
[client]
host     = newt.cavb1vdbmmgn.us-east-1.rds.amazonaws.com
user     = root
password = mypeserver
```
### INSTALAR WORDPRESS
`cd /var/www`  
`wget https://es.wordpress.org/wordpress-5.0-es_ES.tar.gz`  
`tar -xzvf wordpress-5.0-es_ES.tar.gz`  
`mv wordpress tienda `  
`mysql --defaults-file=/etc/mysql/newt.cnf`  
`create database tienda;`  
`exit;`  
`chmod 777 -R /var/www/tienda`
### DATOS DE LA CONEXION 
```
Nombre de la base de datos: blog
Nombre de usuario: root
Contraseña: mypeserver
Servidor de la base de datos: newt.cavb1vdbmmgn.us-east-1.rds.amazonaws.com
```
### DATOS DEL SITIO
```
Título del sitio: Newt
Nombre de usuario: newt
```
`https://tienda.legalprodata.com/wp-login.php`  
### ACTUALIZACIONES DIRECTAS EN WORDPRESS
`vi /var/www/tienda/wp-config.php` 
### AGREGAR ESTO ANTES DEL NOMBRE DE LA BASE DE DATOS
`define('FS_METHOD','direct');`
### CAMBIAR LA HORA DE WORDPRESS
`Ajusters->Generales->Zona Horaria`   
### PLUGINS PARA WORDPRESS
```
YOAST SEO
Smush
Contact Form 7 
```
### CREAR ZONA INVERSAR PARA LOS CORREOS ENVIADOS DESDE AMAZON
### https://aws.amazon.com/es/premiumsupport/knowledge-center/route-53-reverse-dns/
### https://aws.amazon.com/forms/ec2-email-limit-rdns-request
### GOOGLE ANALYTICS
### https://josefacchin.com/google-analytics-espanol-analitica-web/
### https://romualdfons.com/mejores-plugins-wordpress/
### FALTA VALIDAR
```
#INSTALAR DRUPAL 8 EN SERVIDOR
#DETENER NGINX
service nginx stop
#SUBIR LA CONFICURACION DE DRUPAL8 A NGINX
copiar blog a /etc/ngix/sites-available
#CREAR ENLANCE SIMBOLICO
ln -s /etc/nginx/sites-available/blog /etc/nginx/sites-enabled/blog
#INICIAR NGINX
service nginx start
#CREAR ARCHIVOS PARA DRUPAL8
aptitude install php7.0-gd
apt-get install php-uploadprogress
aptitude purge apache2
service php7.0-fpm restart
service nginx restart
cd /var/www
wget https://ftp.drupal.org/files/projects/drupal-8.4.0.tar.gz
tar -xzvf drupal-8.4.0.tar.gz
mv drupal-8.4.0 blog
chmod 777 -R /var/www/blog
#CREAR ARCHIVO DE CONEXION PARA AMAZON RDS
vi /etc/mysql/newt.cnf
##COPIAR AL ARCHIVO ESTA INFORMACION##
[client]
host     = newtmaria.csdlywkzvt6k.us-east-1.rds.amazonaws.com
user     = root
password = mypeserver
#UTILIZAR EL ARCHIVO PARA INGRESAR A LA BASE DE DATOS
mysql --defaults-file=/etc/mysql/newt.cnf
create database blog;
CREATE USER blog@'%' IDENTIFIED BY 'root';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER, CREATE TEMPORARY TABLES ON blog.* TO 'blog'@'%' IDENTIFIED BY 'root'; 
flush privileges;
quit
#COPIAR ARCHIVOS PARA INSTALACION DE DRUPAL
cd /var/www/blog
cp sites/default/default.settings.php sites/default/settings.php
chmod 777 -R /var/www/blog
#COMENZAR INSTALACION
https://blog.legalprodata.com
#DATOS DE INSTALACION
Servidor: newtmaria.csdlywkzvt6k.us-east-1.rds.amazonaws.com
#TERMINANDO INSTALACION
cd /var/www/blog
chmod go-w sites/default/settings.php
chmod go-w sites/default
#MODIDICAR EL ARCHIVO SETTING.PHP EN LA LINEA 746
vi sites/default/settings.php
##AGREGAR ESTO##
$settings['trusted_host_patterns'] = array(
    '^newt\.pe$',
    '^.+\.newt\.pe$',
   );
#ELIMINANDO INSTALACION
rm core/install.php
#PERMISOS PARA COPIAR ARCHIVOS A DRUPAL
chmod 777 -R /var/www/blog/themes
chmod 777 -R /var/www/blog/modules
#INSTALAR MODULOS DRUPAL 8
cd /var/www/blog/modules/contrib
tar -xzvf devel-8.x-1.2.tar.gz
Modulos->Modulo Devel y Devel Kint
tar -xzvf search_kint-8.x-1.0.tar.gz
Modulos->Search Kint
tar -xzvf diff-8.x-1.0-rc1.tar.gz
Modulos->Diff
#ACTUALIZAR CORE DRUPAL 8
#PARA APLICAR LOS PARCHE COPIAR TODO EL CONTENIDO DE UNA CARPETA A OTRA
cp -r /home/drupal-8.4.0-rc2/* /var/www/blog/
#COMENTARIO SOBRE ERRORES EL {# {{ kint(page.content) }} #}
#SOLO SE PUEDE USAR CUANDO SE DARROLLA, SI SE TRATA DE VER LA WEB
#CON ESE METODO DECLARADO BOTA ERROR, PARA PRODUCCION COMENTARLO
#CONFIGURAR ENTORNO DE DESARROLLO DE DRUPAL 8
cd /var/www/blog
cp sites/default/default.services.yml sites/default/services.yml
#MODIFICAR debug: true EN LINEA 58
vi sites/default/services.yml # debug: true
#MODIFICAR auto_reload: true EN LINEA 67
vi sites/default/services.yml # auto_reload: true
#MODIFICAR cache: false EN LINEA 78
vi sites/default/services.yml # cache: false
#HABILITAR TWIG DEBUG EN SETTINGS
vi sites/default/settings.php
##AGREGAR ESTO AL FINAL##
$settings['twig_debug'] = TRUE;
#DESAGRUPAR ARCHIVOS CSS
https://blog.legalprodata.com/admin/config/development/performance
#CONFIGURAR SITIO DRUPAL 8
cd /var/www/blog
cp sites/example.settings.local.php sites/default/settings.local.php
#DESCOMENTAR LAS SIGUIENTES LINEAS
vi sites/default/settings.php # EN LA LINEA 786
if (file_exists($app_root . '/' . $site_path . '/settings.local.php')) {
   include $app_root . '/' . $site_path . '/settings.local.php';
}
#COMENTAR $config['system.logging']['error_level'] = 'verbose'; EN LA LINEA 47
vi sites/default/settings.local.php #COMENTAR #
#DESCOMENTAR $settings['cache']['bins']['render'] = 'cache.backend.null';  EN LA LINEA 67
vi sites/default/settings.local.php #DESCOMENTAR
#DESCOMENTAR $settings['cache']['bins']['dynamic_page_cache'] = 'cache.backend.null';  EN LA LINEA 84
vi sites/default/settings.local.php #DESCOMENTAR
#EN FILE SYSTEM CAMBIAR EL TIEMPO DE ELIMINACION A 4 SEMANAS
#CONFIGURAR EL CACHE SETTING DE LOS BLOQUES EN 1 DIA
#CREAR UN USUARIO NUEVO PARA NO USAR EL ADMINISTRADOR POR DEFECTO
#PARA APLICAR LOS PARCHE COPIAR TODO EL CONTENIDO DE UNA CARPETA A OTRA
cp -r /home/drupal-8.4.0-rc2/* /var/www/blog/
#CONFIGURAR SMS
#ABRIR UN CASO PARA AUMENTAR EL GASTO MENSUAL DEL SMS
#CREAR LA TABLA PARA LOS MENSAJES DE TEXTO
#CREAR UN BUCKET EN AMAZON S3 PARA GUARDAR LOS REPORTES DE ENVIO
Create Bucket
Name: sns-sms-uso-diario
Dejar todo por defecto y darle a create bucket
#ENTRAR AL BUCKET CREADO Y LUEGO IR A 
Permissions->Bucket Policy
#COPIAR TODO ESTO AL EDITOR
{
    "Version": "2012-10-17",
    "Id": "sns-sms-uso-diario-politica",
    "Statement": [
        {
            "Sid": "AllowPutObject",
            "Effect": "Allow",
            "Principal": {
                "Service": "sns.amazonaws.com"
            },
            "Action": "s3:PutObject",
            "Resource": "arn:aws:s3:::sns-sms-uso-diario/*"
        },
        {
            "Sid": "AllowGetBucketLocation",
            "Effect": "Allow",
            "Principal": {
                "Service": "sns.amazonaws.com"
            },
            "Action": "s3:GetBucketLocation",
            "Resource": "arn:aws:s3:::sns-sms-uso-diario"
        }
    ]
}
#DECIRLE AL SNS QUE GUARDE LOS MENSAJES EN EL BUCKET
SNS->Text Messaging->Manage text messaging preferences
Reports Storage: sns-sms-uso-diario
Update Preferences
#INSTALAR TCEXAM SIN MARIADB EN PHP7
#ESPERANDO UNA VERSION QUE FUNCIONE CON CHROME
#POR EL MOMENTO SOLO FUNCIONA CON FIREFOX Y NO INSTALA EL ACPI
aptitude install acpi
aptitude install ghostscript gsfonts imagemagick libauthen-pam-perl libio-pty-perl libnet-ssleay-perl libpam-runtime lm-sensors
aptitude install openssl perl ssh texlive-binaries zbar-tools
aptitude install php7.0-gd php7.0-cli php7.0-intl php7.0-imagick php7.0-curl php7.0-mcrypt php7.0-memcache php7.0-mysql php7.0-opcache
cd /var/www/
#COPIAR tcexam-master.zip a /var/www/
aptitude install unzip
unzip tcexam-master.zip
rm tcexam-master.zip
mv tcexam-master quiz
#PERMISO A TODA LA CARPETA
chmod 777 -R /var/www/quiz
#DESCOMENTAR LAS LINEAS DE TCEXAM EN default-ssl
vi /etc/nginx/sites-available/default-ssl
#REINICIAR PHP Y NGINX
service php7.0-fpm restart
service nginx restart
#INSTALAR DESDE LA SIGUIENTE URL
https://legalprodata.com/quiz/install/install.php
#BORRAR LA CARPETA DE INSTALACION
rm /var/www/quiz/install/ -r
#COPIAR EL BACKUP A /var/www/quiz/cache/backup/
#MODIFICAR LA CONFIGURACION DEL CORREO
vi quiz/shared/config/tce_email_config.php
$emailcfg['AdminEmail'] = 'noreply@legalprodata.com';
$emailcfg['From'] = 'noreply@legalprodata.com';
$emailcfg['FromName'] = 'newt Quiz';
$emailcfg['Mailer'] = 'sendmail';
#MODIFICAR LA CANTIDAD DE REGISTROS A MOSTRAR
vi quiz/admin/config/tce_config.php
define('K_MAX_ROWS_PER_PAGE', 500);
#INSTALAR VTIGERCRM
#COPIAR VTIGER A /var/www
aptitude install php7.0-imap php7.0-curl
cd /var/www
tar -xzvf vtigercrm6.5.0.tar.gz
chmod 777 -R /var/www
#DESCOMENTAR LAS LINEAS DE VTIGERCRM EN default-ssl
vi /etc/nginx/sites-available/default-ssl
#REINICIAR PHP Y NGINX
service php7.0-fpm restart
service nginx restart
#INGRESAR DESDE LA SIGUIENTE URL
https://legalprodata.com/crm
#MODIFICAR SEGUN LO REGOMENDADO
vi /etc/php7.0/fpm/php.ini
service php7.0-fpm restart
#INGRESAR DESDE LA SIGUIENTE URL
https://legalprodata.com/crm
#ESCOGER Sales Automation e Invoicing & Inventory Management & Marketing
#CONFIGURAR CORREO
Configuracion CRM->Configuracion Adicional->Configuracion del Servidor de correo
Nombre del servidor: localhost
#CONFIGURAR DATOS DE LA EMPRESA
Configuracion CRM->Plantillas->Informacion de la Empresa
Logo en 170 x 60
#CONFIGURAR IMPUESTO DE LA EMPRESA
Configuracion CRM->Configuracion Adicional->Configuracion de Impuestos
#ELIMINAR TODOS LOS IMPUESTO Y AÑADIR UNO NUEVO
Nombre IGV
Valor 18%
#CREAR USUARIO DE VENTA
#CREAR UN PRESUPUESTO A UNA NUEVA CUENTA
#CREAR UNA NUEVA CUENTA (QUE SON LOS DATOS DE LA EMPRESA)
#CREAR UN CONTACTO
#LUEGO REGISTRAR LA OPORTUNIDAD
#LUEGO CREAR LOS SERVICIOS
### INSTALAR WEB DE VENTAS RETAIL
### INSTALAR DEPENDENCIAS NECESARIAS
aptitude install php7.0-gd php7.0-xml php7.0-zip php7.0-curl
### CREAR CARPETA
mkdir /var/www/retail
chmod 777 -R /var/www/retail
### SUBIR ARCHIVOS A LA WEB POR STRIDER
vi /root/.ssh/authorized_keys
### DESCOMENTAR LAS LINEAS DE retail EN default-ssl
vi /etc/nginx/sites-available/default-ssl
service php7.0-fpm restart
service nginx restart
### INSTALAR COMPOSER
cd /usr/src
curl -sS https://getcomposer.org/installer | sudo php -- --install-dir=/usr/local/bin --filename=composer
composer --version
cd /var/www/retaildemo/controller/pdf/
composer install
### INSTALAR DRIVER SQL EN PHP7
aptitude install php7.0 php7.0-fpm php7.0-dev php7.0-mcrypt php7.0-mbstring php7.0-xml 
aptitude install mcrypt php-pear
aptitude install apt-transport-https
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add - 
curl https://packages.microsoft.com/config/ubuntu/16.04/prod.list > /etc/apt/sources.list.d/mssql-tools.list
aptitude update
sudo ACCEPT_EULA=Y apt-get install mssql-tools
aptitude install unixodbc-dev
echo 'export PATH="$PATH:/opt/mssql-tools/bin"' >> ~/.bashrc
source ~/.bashrc
### PROBAR LA CONEXION DE BASE DE DATOS
/opt/mssql-tools/bin/sqlcmd -S 10.136.67.151 -U sa -P Qa123456
/opt/mssql-tools/bin/sqlcmd -S 10.136.67.151 -U sa -P Qa123456 -Q "SELECT @@VERSION"
pecl install sqlsrv pdo_sqlsrv
### AGREGAR LO SIGUIENTE EN PHP.INI EN LA LINA 876
vi /etc/php/7.0/fpm/php.ini 
extension= pdo_sqlsrv.so
extension= sqlsrv.so
service php7.0-fpm restart
service nginx restart
### LIBREARIAS PARA SQL
aptitude install freetds-common freetds-bin unixodbc php5-sybase
service php5-fpm restart
service nginx restart
sudo pecl install sqlsrv pdo_sqlsrv
sudo echo "extension= pdo_sqlsrv.so" >> `php --ini | grep "Loaded Configuration" | sed -e "s|.*:\s*||"`
sudo echo "extension= sqlsrv.so" >> `php --ini | grep "Loaded Configuration" | sed -e "s|.*:\s*||"`
tsql -H 10.136.63.232 -p 1433 -U sa -P Qa123456 -D BDNava01
vi /etc/freetds/freetds.conf
[SQL]
host = 10.136.63.232
port = 1433
tds version = 8.0
tsql -S SQL -U sa -P Qa123456 -D BDNava01
### INSTALAR TCEXAM CON MARIADB
aptitude install acpid ghostscript gsfonts imagemagick libauthen-pam-perl libio-pty-perl libnet-ssleay-perl libpam-runtime lm-sensors
aptitude install mariadb-client mariadb-server openssl perl ssh texlive-binaries zbar-tools
aptitude install php5-gd php5-cli php5-intl php5-imagick php5-curl php5-mcrypt php5-memcache php5-mysql php5-xcache
cd /var/www/
### COPIAR tcexam-master.zip
aptitude install unzip
unzip tcexam-master.zip
rm tcexam-master.zip
mv tcexam-master quiz
### PERMISO A TODA LA CARPETA
chmod 777 -R /var/www/quiz
### DESCOMENTAR LAS LINEAS DE TCEXAM EN default-ssl
vi /etc/nginx/sites-available/default-ssl
### REINICIAR PHP Y NGINX
service php5-fpm restart
service nginx restart
### INSTALAR DESDE LA SIGUIENTE URL
https://legalprodata.com/quiz/install/install.php
### BORRAR LA CARPETA DE INSTALACION
rm /var/www/quiz/install/ -r
### COPIAR EL BACKUP A /var/www/quiz/cache/backup/
### MODIFICAR LA CONFIGURACION DEL CORREO
vi quiz/shared/config/tce_email_config.php
$emailcfg['AdminEmail'] = 'noreply@legalprodata.com';
$emailcfg['From'] = 'noreply@legalprodata.com';
$emailcfg['FromName'] = 'Newt Quiz';
$emailcfg['Mailer'] = 'sendmail';
### MODIFICAR LA CANTIDAD DE REGISTROS A MOSTRAR
vi quiz/admin/config/tce_config.php
define('K_MAX_ROWS_PER_PAGE', 500);
### INSTALAR PHPLIST
### COPIAR PHPLIST a /var/www
tar -xzvf phplist-3.2.6.tgz
cd phplist-3.2.6/public_html/
mv lists/ /var/www/phplist
cd /var/www/
rm phplist-3.2.6 -r
chmod 777 -R /var/www
### DESCOMENTAR LAS LINEAS DE MAILING EN default-ssl
vi /etc/nginx/sites-available/default-ssl
### REINICIAR PHP Y NGINX
service php5-fpm restart
service nginx restart
### CREAR BASE DEDATOS
mysql -u root -p
create database mailing;
quit;
### MODIFICAR LA CONEXION EN EL ARCHIVO PHPLIST
vi /var/www/phplist/config/config.php
### AGREGAR
$default_system_language = "es";
### MODIFICAR
$database_name = 'mailing';
$database_user = 'root';
$database_password = 'clave';
### INGRESAR DESDE LA SIGUIENTE URL
https://legalprodata.com/mailing/admin/
### HACER CLICK EN INICIAR BASE DE DATOS
```
### SELECCIONAR EL PROYECTO EN NODE Y HACER CLICK EN ADD
### SELECCIONAR CUSTOM
### IR A CONGIURE
### EN SETTINGS COPIAR EL PUBLIC KEY EN LA SIGUIENTE RUTA
`https://github.com/giovanniAlexander/libellum_facturacion_api/settings/keys` -> Add Deploy Key  
```
Title: Libellum Facturacion Api
Key: Copiar valor de public key
Check Allo write Acces
```
### IR A LA SECCION DE PLUGIN Y AGREGAR
`Email Notifier`  
`SSh Deploy`  
### CONFIGURAR SSH DEPLOY
### AGREGAR PUBLIC KEY AL SERVIDOR QUE SE CONECTAR ( POR EJEMPLO ACA SE AGREGA ESTE VALOR EN EL SERVIDOR DE legalprodata.com)
`vi /root/.ssh/authorized_keys`  
`Copiar valor de public key`  
### CREAR CARPETA PARA EL  API
`mkdir /home/facturacion_api`
### AGREGAR USUARIO Y HOST (AQUI VA EL ROOT DEL SERVIDOR, POR EJEMPO SI SE VA CONECTAR legalprodata.com A legalprodata.com AQUI IRIA root@legalprodata.com
`root@legalprodata.com`  
`check Transfer bundle?`  
### CONFIGURAR LOS SIGUIENTES COMANDOS EN  EL SHELL
```shell
cd /home/facturacion_api/
pm2 stop facturacion.js
#ELIMINAR LOS ARCHIVOS ANTERIORES
rm -R /home/facturacion_api/*
#COPIAR TODOS LOS ARCHIVOS DE LA WEB
cp -r /root/giovannialexander_libellum_facturacion_api/* /home/facturacion_api/
npm install
npm unistall -S nodemon 
pm2 start facturacion.js
pm2 save
```
### SIEMPRE HACERLE UN TEST Y UN DEPLOY PRIMERO ANTES DEL COMMIT



### INSTALAR MONGODB
`aptitude install mongodb`  
`mongod --version`  
### CREAR USUARIO ADMINISTRADOR
`mongo`  
`use admin`  
```
db.createUser(
  {
    user: "sunat",
    pwd: "sunat",
    roles: [ { role: "userAdminAnyDatabase", db: "admin" } ]
  }
);
```
`exit` 
### RESTRINGIR EL ACCESO NO AUTORIZADO
`vi /etc/mongodb.conf` #auth=true  
`service mongodb restart`  
### CREAR UN NUEVO USUARIO PARA BASE SUNAT
`mongo -u sunat -p sunat --authenticationDatabase admin`  
`use sunat`  
```
db.createUser(
  {
    user: "sunat",
    pwd: "sunat",
    roles: [ { role: "readWrite", db: "sunat" } ]
  }
);
```
`exit`  
### INSERTAR REGISTROS EN BASE SUNAT
`mongo -u sunat -p sunat --authenticationDatabase sunat`  
`use sunat`  
```
db.sunat.save({
    "RUC": "20272209325",
    "NOMBRE O RAZÓN SOCIAL": "PESCA PERU MOLLENDO S.A.",
    "ESTADO DEL CONTRIBUYENTE": "BAJA DEFINITIVA",
    "CONDICIÓN DE DOMICILIO": "HABIDO",
    "UBIGEO": "150122",
    "TIPO DE VÍA": "AV.",
    "NOMBRE DE VÍA": "JOSE PARDO",
    "CÓDIGO DE ZONA": "-",
    "TIPO DE ZONA": "-",
    "NÚMERO": "601",
    "INTERIOR": "1603",
    "LOTE": "-",
    "DEPARTAMENTO": "-",
    "MANZANA": "-",
    "KILÓMETRO": "-"
})
```
### MOSOTRAR TODOS LOS DATOS
`db.sunat.find()`  
### MOSTRAR COLECCIONES
`show collections`  
### ELIMINAR TODAS LAS COLECCION
`db.sunat.remove({})`  
### ELIMINAR LA BASE DE DATOS
`db.dropDatabase()`  
### PROBANDO MIGRACION DE ARCHIVOS GRANDES
`iconv -f iso-8859-1 -t utf-8 padron_reducido_ruc.txt > padron_reducido_ruc_ok.txt`  
`tr '|' \\t < padron_reducido_ruc_ok.txt > data.tsv`  
`mongod --nojournal`  
`ulimit -a`  
`mongoimport  -u sunat -p sunat --authenticationDatabase sunat -d sunat -c sunat --type tsv --file data.tsv --headerline`  
