### MIGRA CORREO DE UN SERVIDOR A OTRO
### INSTALAR IMAPSYNC
### INSTLAR GIT
`aptitude install git`  
### CREAR CARPETA PARA SYNC E INGRESAR
`mkdir /home/backupimap`  
`cd  /home/backupimap`  
### CLONAR EL REPOSITORIO
`git clone https://github.com/imapsync/imapsync.git`  
`cd imapsync`  
### VER LOS REQUERIMIENTOS PARA DEBIAN 9
```
cat INSTALL.d/INSTALL.Debian.txt
aptitude install libjson-webtoken-perl libauthen-ntlm-perl libcgi-pm-perl libcrypt-openssl-rsa-perl libdata-uniqid-perl libfile-copy-recursive-perl
aptitude install libio-socket-inet6-perl libio-socket-ssl-perl libio-tee-perl libhtml-parser-perl libjson-webtoken-perl libmail-imapclient-perl
aptitude install libparse-recdescent-perl libmodule-scandeps-perl libreadonly-perl libregexp-common-perl libsys-meminfo-perl libterm-readkey-perl
aptitude install libtest-mockobject-perl libtest-pod-perl libunicode-string-perl liburi-perl libwww-perl libtest-nowarnings-perl libtest-deep-perl
aptitude install libtest-warn-perl make cpanminus
```
### PROBAR SI LA CONFIGURACION ESTA BIEN
`./imapsync --testslive`  
### INSTALARLO COMO COMANDO
`cp imapsync /usr/bin/`  
### MIGRAR CORREOS DE UN SERVIDOR REMOTO A OTRO LOCAL CON TLS
```
imapsync --host1 legalprodata.com   --user1 hola   --password1 'Qa123456' \
         --tls2 --host2   localhost   --user2 holalegalprodata   --password2 'Qa123456'
```
### MIGRAR CORREOS DE UN SERVIDOR LOCAL A OTRO REMOTO CON TLS
```
imapsync --host1 localhost   --user1 jimy  --password1 'Qa123456' \
         --tls2 --host2   legalprodata.com   --user2 jimy.morales  --password2 'Qa123456'
```
#### COMPROBAR QUE LOS CORREOS SE MIGRARON BIEN
### ESCOGER US East (N. Virginia) us-east-1
### CREAR LA NUEVA RED PARA TRABAJAR EN AMAZON
`https://console.aws.amazon.com/vpc/home?region=us-east-1`  
### YOUR VPCs
### CREAR VPC
```
Name tag : legalprodata-vpc
IPv4 CIDR block* : 10.10.0.0/16
IPv6 CIDR block: No IPv6 CIDR Block
Tenancy: Default  
```
### MODIFICAR EL VPC PARA QUE EL DNS HOSTNAME SEA AUTOMATICO
`Actions->Edit DNS Hostnames->enable`  
### CREAR INTERNET GATEWAY
`Name tag : legalprodata-gateway`  
### LUEGO AGREGARLO AL VPC
`Attach to VPC -> legalprodata-vpc`  
### AUTOMATICAMENTE SE CREA EL ROUTE-TABLE MODIFICAR EL NOMBRE QUE ESTA ASOCIADO A legalprodata-vpc
`legalprodata-route`  
### AGREGAR ROUTES EN ROUTE-TABLE
```
Destination: 0.0.0.0/0
Target: legalprodata-gateway
```
### AUTOMATICAMENTE SE CREA EL SECURITY GROUP SOLO MODIFICAR EL NOMBRE QUE ESTA ASOCIADO A legalprodata-vpc
`legalprodata-security`  
### AGREGAR PERMISOS PARA CONEXIONES REMOTAS
### SELECCIONAR legalprodata SECURITY
`legalprodata-security->Inbound Rules -> Edit -> Add Another Rule`  
```
Type : All traffic
Protocol : All
Port range :  ALL
Source : 0.0.0.0/0 
```
### CREAR SUBNET POR CADA ZONA
### CADA VEZ QUE SE CREA UNA NUEVA SUBNET NO SE UTILIZA LOS IPS 1,2 Y 3
### POR EJEMPLO SI CREO LA NUEVA ZONA 10.10.30.0/24 NO PODRE USAR LAS IPS 10.10.30.1,10.10.30.2 Y 10.10.30.3
### ZONA 1A
```
Name tag : legalprodata-subnet-1a
VPC: legalprodata-vpc
Availability Zone : us-east-1a
IPv4 CIDR block : 10.10.30.0/24
```
`SELECCIONAR SUBNET ACTIONS Y HABILITA auto-asing IP`  
### ZONA 1B
```
Name tag : legalprodata-subnet-1b
VPC: legalprodata-vpc
Availability Zone : us-east-1b
IPv4 CIDR block : 10.10.31.0/24
```
`SELECCIONAR SUBNET ACTIONS Y HABILITA auto-asing IP`  
### ZONA 1C
```
Name tag : legalprodata-subnet-1c
VPC: legalprodata-vpc
Availability Zone : us-east-1c
IPv4 CIDR block : 10.10.32.0/24
```
`SELECCIONAR SUBNET ACTIONS Y HABILITA auto-asing IP`  
### ZONA 1D
```
Name tag : legalprodata-subnet-1d
VPC: legalprodata-vpc
Availability Zone : us-east-1d
IPv4 CIDR block : 10.10.33.0/24
```
`SELECCIONAR SUBNET ACTIONS Y HABILITA auto-asing IP`  
### ZONA 1E
```
Name tag : legalprodata-subnet-1e
VPC: legalprodata-vpc
Availability Zone : us-east-1e
IPv4 CIDR block : 10.10.34.0/24
```
`SELECCIONAR SUBNET ACTIONS Y HABILITA auto-asing IP`  
### AUTOMATICAMENTE SE CREA EL NETWORK ACL SOLO MODIFICAR EL NOMBRE QUE ESTA ASOCIADO A legalprodata-vpc
`legalprodata-acl`  
### BORRAR LA RED INICIAL
### CREAR CLAVE PUBLICA Y PRIVADA WINDOWS
### INSTALAR CLIENTE GIT (GIT BASH)
```
mkdir /d/ssl
cd /d/ssl
ssh-keygen -t rsa -C “hola@legalprodata.com”
```
### ESCOGER LA RUTA DONDE SE GUARDARA LA LLAVE Y EL NOMBRE
`Enter file in which to save the key (/root/.ssh/id_rsa): /d/ssl/legalprodata`  
### PONERLE CLAVE A LOS ARCHIVOS POR SEGURIDAD
`Enter passphrase (empty for no passphrase): #aquituclave#`  
### GENERA EL ARCHIVO .ppk PARA CONECTARSE POR PUTTY
### DESDE WINDOWS
```
ABRIR puttygen.exe
HACER CLICK EN LOAD Y SELECCIONAR legalprodata (PARA VERLO ESCOGER ALL FILES .)
PONER LA CLAVE QUE SE PUSO AL CREAR Y DARLE ACEPTAR
HACER CLICK EN SAVE PRIVATE KEY Y SELECCIONAR DONDE GUARDAR EL ARCHIVO
GUARDAR EL ARCHIVO CON LA EXTENSION .ppk (legalprodata.ppk)
ABRIR puttygen.exe
HACER CLICK EN LOAD Y SELECCIONAR legalprodata.ppk
PONER LA CLAVE QUE SE PUSO AL CREAR Y DARLE ACEPTAR
HACER CLICK EN CONVERSIONS->EXPORT OPEN SSH KEY
GUARDAR EL ARCHIVO CON LA EXTENSION .pem (legalprodata.pem)
```
### DESDE LINUX
```
aptitude install putty-tools
puttygen legalprodata -o legalprodata.ppk
puttygen legalprodata.ppk -O private-openssh -o legalprodata.pem
```
### PARA USAR LAS LLAVES EN UNA CONEXION AL SERVIDOR SE INGRESA LA INFORMACION
### DEL ARCHIVO .pub EN LA CONFIGURACION DEL SERVIDOR Y EL ARCHIVO .ppk
### SE USA PARA ESTABLECER LA CONEXION DESDE EL PUTTY
### CREAR KEY PAIRS
### ENTRAR A INSTANCIAS>NETWORK & SECURITY > KEY PAIRS
```
Import key pair
Load public key from file : Seleccionar archivo .pub
```
### CREAR IP  PULICA ASOCIADA
### ENTRAR A INSTANCIAS>NETWORK & SECURITY > ELASTIC IPS
`ALLOCATE NEW ADDRESS > ALLOCATE`  
### CREAR INSTANCIA EC2
### ESCOGER LA IMAGEN DEL SIGUIENTE LINK
### US East (N. Virginia) us-east-1
`https://wiki.debian.org/Cloud/AmazonEC2Image`  
`ami-0f9e7e8867f55fd8e`  
### ELEGIR LA INSTANCIA
`t3.micro`  
### ESCOGER IP
`10.10.30.4`  
### ESCOGER STORAGE
`30GB`  
### SELECCIONAR EL SECURITY GROUP YA CREADO
`legalprodata-security`  
### ASOCIAR LA IP SEPARADA ANTERIORMENTE
`ACTIONS > ASSOCIATE ADDRESS` 
 ```
 Resource type: Instance
 Instace: Instacia Creade
 Private ip: Ip Creado
 Check en Reassociation 
 ```
### LOGUEARSE CON EL IP PUBLICO Y LA LLAVE PRIVADA
### PRIMERO LOGUEARSE CON USUARIO admin Y LUEGO ESCRIBIR sudo su
### CREAR DOMINIO EN ROUTE S53
### CREAR ZONA DE DNS EN AMAZON CON ROUTE53
```
Create Hosted Zone
Domain Name: legalprodata.com
Comment: Dominio legalprodata.com
Type: Public Hosted Zone
```
### CONFIGURAR DOMINIO QUE APUNTE A ROUTE S53
### CONFIGURAR DNS COMO LA FOTO DNS.PNG
### IR AL DASHBOARD Y SELECCIONAR EL DOMINIO CREADO
### LUEGO CONFIGURAR LOS DNS MOSTRADOS EN LA PAGINA DONDE SE COMPRO EL DOMINIO
### LUEGO CREAR TODOS LOS REGISTROS NECESARIOS PARA LA WEB
### MODIFICAR REPOSITORIO
`vi /etc/apt/sources.list`  
### ACTUALIZAR SISTEMA
`apt-get update`  
`apt-get install aptitude`  
`aptitude update`  
`aptitude upgrade`  
`aptitude install vim`  
`reboot`  
### RECONFIGURAR VIM
`vi /etc/vim/vimrc`  
`update-alternatives --config editor` #seleccionar vim.basic  
### COMENTAR LAS LINEAS DEL SIGUIENTE ARCHIVO SI ES NECESARIO
`vi /usr/share/vim/vim80/defaults.vim`  
### DEBE QUEDAR ASI
```
" In many terminal emulators the mouse works just fine.  By enabling it you
" can position the cursor, Visually select and scroll with the mouse.
"if has('mouse')
"  set mouse=a
"endif
```
### VER CUANTO DISCO DURO OCUPA LOS PAQUETES
`du -sh /var/cache/apt/archives`  
### BORRAR LOS PAQUETES DE ACTUALIZACION
`aptitude clean`  
### RECONFIGURAR DIA Y HORA
`dpkg-reconfigure tzdata`  
### LIBERAR MEMORIA CADA 5 MINUTOS EN CRON
`aptitude install sudo`  
`cd /home`  
`vi liberar.sh`  
```shell
## LIBERAR MEMORIA
sudo sync && sudo sysctl -w vm.drop_caches=3
```
`chmod 777 liberar.sh`  
### CREAR TAREA QUE SE EJECUTAR CADA HORA
`crontab -e`  
### NO MANDAR CORREO DEL RESULTADO DEL CRON
`MAILTO=""`  
### SI SALE PARA SELECCIONAR EDITOR ESCOGER vim.basic
### EJECUTAR CADA 5 MINUTOS
`*/5 * * * * bash /home/liberar.sh`  
### EJECUTAR CADA HORA
`0 * * * * bash /home/liberar.sh`  
### CREAR BASE DE DATOS EN RDS
### CREAR SIEMPRE UN NUEVO GRUPO DE PARAMETROS EN 
`https://console.aws.amazon.com/rds/home?region=us-east-1#parameter-groups:id=`  
### SELECCIONAR ESE GRUPO DE PARAMETROS CUANDO SE CREA LA BASE DE DATOS
### US East (N. Virginia) us-east-1
`Seleccionar Only enable options elegible for RDS Free Usage Tier Info`  
### SELECCIONAR MARIADB
### DISCO DURO
`20GB`  
### CONFIGURACION DE LA BASE DE DATOS
```
DB Instance Identifier*: legalprodata
Master Username*: root
Master Password*: mypeserver
Confirm Password*: mypeserver
```
### CONFIGURACIONES AVANZADAS
```
VPC*: legalprodata-vpc
Subnet Group: Create new DB Subnet Group
Publicly Accessible: No
Availability Zone: us-east-1a
VPC Security Group(s): default (VPC)
Database Name: legalprodata
```
### LUEGO DE CREAR EL SERVIDOR ENTRAR A SECURITY GROUPS Y MODIFICAR ACCESO
`https://console.aws.amazon.com/ec2/v2/home?region=us-east-1#SecurityGroups`  
### ESCOGER EL GRUPO CREADO POR RDS
`rds-launch-wizard->Inbound Rules -> Edit`  
```
Type : All traffic
Protocol : All
Port range :  ALL
Source : 0.0.0.0/0  
```
### INSTALAR CLIENTE MYSQL PARA CONECTARSE A RDS
`aptitude install mysql-client`  
### PROBAR CONEXION
`mysql -u root -p -h marialegalprodata.cbekd1fkod8w.us-east-1.rds.amazonaws.com`  
### CREAR CERTIFICADO SSL AUTO GENERADO
`cd /etc/ssl/`  
`sudo openssl req -new -nodes -keyout private/legalprodata.key -out legalprodata.csr -days 3650`  
`sudo openssl x509 -req -days 3650 -in legalprodata.csr -signkey private/legalprodata.key -out certs/legalprodata.crt`  
### CONFIGURAR CERTIFICADO SSL COMPRADO EN NAMECHEAP
### CREAR UNA CLAVE PRIVADA EN NUESTRO SERVIDOR Y CREAMOS UN CERTIFICATE SIGNING REQUEST(CSR) 
### PARA SOLICITAR NUESTRO CERTIFICADO SSL A UNA ENTIDAD DE AUTORIZACIÓN RECONOCIDA
`cd /etc/ssl`  
`openssl req -new -newkey rsa:2048 -nodes -keyout private/legalprodata.com.key -out legalprodata.com.csr`  
### RESPONDER LOS DATOS SOLICITADOS
```
Country Name (2 letter code) [AU]:PE
State or Province Name (full name) [Some-State]:Lima
Locality Name (eg, city) []:Lima
Organization Name (eg, company) [Internet Widgits Pty Ltd]:Peritum
Organizational Unit Name (eg, section) []:TI
Common Name (e.g. server FQDN or YOUR name) []:legalprodata.com
Email Address []:hola@legalprodata.com
Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []: Peritum
```
### SEGUIR TODOS LOS PASOS EN LA WEB HASTA OBTENER EL ARCHIVO .crt Y .ca-bundle
`cat legalprodata.com.csr`  
`mkdir /home/ssl`  
`chmod 777 -R /home/ssl`  
### SUBIR EL ARCHIVO .crt Y .ca-bundle A /home/ssl
`cd /home/ssl`  
`cat legalprodata_pe.crt legalprodata_pe.ca-bundle >> legalprodata.com.crt`  
`cp legalprodata.com.crt /etc/ssl/certs/`  
`rm legalprodata.com.crt`  
`rm legalprodata_pe.crt`  
`rm legalprodata_pe.ca-bundle`  
`cd /etc/ssl`  
`openssl x509 -subject -fingerprint -noout -in certs/legalprodata.com.crt`  
`chmod 400 certs/legalprodata.com.crt private/legalprodata.com.key`  
`rm /home/ssl -R`  
### INSTALAR NGINX
`aptitude install nginx`  
### CONFIGURAR SITIO SSL EN NGINX
### CONFIGURAR CERTIFICADO CON CERBOT Y SSL LETS ENCRYPT
`aptitude install certbot`  
`aptitude install nginx`  
`certbot certonly -a webroot --webroot-path=/var/www/html -d demosoft.legalprodata.com`  
### RUTA DONDE ESTAN LOS ENLACES DE CERTIFICADOS
`cd /etc/letsencrypt/live/demosoft.legalprodata.com/`  
`ls`  
### RUTA DONDE ESTAN LOS CERTIFICADOS VERDADEROS
`cd /etc/letsencrypt/archive/demosoft.legalprodata.com/`  
`ls`  
### CREAR ENLACE SIMBOLICO PARA LOS CERTIFICADOS
`ln -s /etc/letsencrypt/live/demosoft.legalprodata.com/fullchain.pem /etc/ssl/certs/legalprodata.com.crt`  
`ln -s /etc/letsencrypt/live/demosoft.legalprodata.com/privkey.pem /etc/ssl/private/legalprodata.com.key`  
`cd /etc/ssl`  
`openssl x509 -subject -fingerprint -noout -in certs/legalprodata.com.crt`  
`chmod 400 certs/legalprodata.com.crt private/legalprodata.com.key`  
### INSTALAR NGINX
`aptitude install nginx`  
### CONFIGURAR SITIO SSL EN NGINX
### DETENER NGINX
`service nginx stop`  
### COPIAR ARCHIVOS PARA WEBS
`copiar demosoft a /etc/nginx/sites-available/`  
### ELIMINAR SITIO POR DEFECTO
`rm /etc/nginx/sites-available/default`  
`rm /etc/nginx/sites-enabled/default`  
### CREAR CARPETAS
`mkdir /var/www/demodashboard`  
### CREAR ENLACE SIMBOLICO
`ln -s /etc/nginx/sites-available/demosoft /etc/nginx/sites-enabled/demosoft`  
### INICIAR NGINX
`service nginx start  `

### RENOVAR CERTIFICADO CERTBOT EN MODO PRUEBA
`certbot renew --dry-run`  
### VERIFICAR EL ESTADO DEL CERTIFICADO
`certbot certificates` 

### CREAR TAREA QUE SE EJECUTAR 1 VEZ AL MES PARA ACTUALIZAR LOS CERTIFICADOS
`crontab -e`  
### SI SALE PARA SELECCIONAR EDITOR ESCOGER vim.basic
### REINICIAR EL NGINX 1 VEZ AL MES
`0 3 3 * * systemctl reload nginx` 
### INSTALAR CLIENTE MYSQL PARA CONECTARSE A RDS
`aptitude install mysql-client`  
### CREAR CADENA DE CONEXION PARA USAR SIEMPRE
`vi /etc/mysql/legalprodata.cnf`  
```
[client]
host     = marialegalprodata.cbekd1fkod8w.us-east-1.rds.amazonaws.com
user     = root
password = mypeserver
```
`mysql --defaults-file=/etc/mysql/legalprodata.cnf`  




### INSTALAR NODE
```
aptitude install build-essential curl
curl -sL https://deb.nodesource.com/setup_10.x | bash -
apt-get install -y nodejs
```
#### PROBAR VARIAS VECES
`npm i -g npm`  
`cd /home`  
### AGREGAR ARCHIVO A PM2
### INSTALAR MANEJADOR GLOBAL PM2
`cd /home`  
`npm i -g pm2`  
### INICIAR CON EL SISTEMA PM2
`pm2 startup systemd`  
`pm2 save`  
### COMANDOS ADICIONALES
`pm2 list`  
`pm2 monit`  
`pm2 info index`  
`pm2 stop index`  
`pm2 start index.js`  
`pm2 restart index`  
### QUITAR INICIO
`pm2 unstartup systemd`

### CREAR CARPETA PARA TODAS LAS APIS DE SEGURIDAD
`mkdir /home/seguridad_api`  
### SELECCIONAR EL PROYECTO EN NODE Y HACER CLICK EN ADD
### SELECCIONAR CUSTOM
### IR A CONGIURE
### EN SETTINGS COPIAR EL PUBLIC KEY EN LA SIGUIENTE RUTA
`https://github.com/jimytac/legalprodata_seguridad_api/settings/keys` -> Add Deploy Key  
```
Title: LegalProData Seguridad Api
Key: Copiar valor de public key
Check Allo write Acces
```
### IR A LA SECCION DE PLUGIN Y AGREGAR
`Email Notifier`  
`SSh Deploy`  
`Slack` 
### CONFIGURAR EL SLACK SEGUN LOS PASOS INDICADOS
### CONFIGURAR SSH DEPLOY
### AGREGAR PUBLIC KEY AL SERVIDOR QUE SE CONECTAR ( POR EJEMPLO ACA SE AGREGA ESTE VALOR EN EL SERVIDOR DE demosoft.legalprodata.com)
`vi /root/.ssh/authorized_keys`  
`Copiar valor de public key`  
### CONFIGURAR SSH
### AGREGAR USUARIO Y HOST (AQUI VA EL ROOT DEL SERVIDOR, POR EJEMPO SI SE VA CONECTAR newt.pe A demosoft.legalprodata.com AQUI IRIA root@demosoft.legalprodata.com
`root@demosoft.legalprodata.com`  
`check Transfer bundle?`  
### CONFIGURAR LOS SIGUIENTES COMANDOS EN  EL SHELL
```
cd /home/seguridad_api/
pm2 stop legalprodata-seguridad-api
#ELIMINAR LOS ARCHIVOS ANTERIORES
rm -R /home/seguridad_api/*
#COPIAR TODOS LOS ARCHIVOS DE LA WEB
cp -r /root/jimytac_legalprodata_seguridad_api/* /home/seguridad_api/
#SETEAR VARIABLE DE ENTORNO
#echo 'export NODE_ENV="development"' >> ~/.bashrc
#source ~/.bashrc
cp /home/seguridad_api.env /home/seguridad_api/.env
npm install
npm uninstall -S nodemon
pm2 start legalprodata-seguridad-api-dev.json
#pm2 startup systemd
#pm2 save
```
### SIEMPRE HACERLE UN TEST Y UN DEPLOY PRIMERO ANTES DEL COMMIT

### CREAR CARPETA PARA TODAS LAS APIS DE ENTERPRISE
`mkdir /home/enterprise_api`  
### SELECCIONAR EL PROYECTO EN NODE Y HACER CLICK EN ADD
### SELECCIONAR CUSTOM
### IR A CONGIURE
### EN SETTINGS COPIAR EL PUBLIC KEY EN LA SIGUIENTE RUTA
`https://github.com/jimytac/legalprodata_enterprise_api/settings/keys` -> Add Deploy Key  
```
Title: LegalProData Enterprise Api
Key: Copiar valor de public key
Check Allo write Acces
```
### IR A LA SECCION DE PLUGIN Y AGREGAR
`Email Notifier`  
`SSh Deploy`  
`Slack` 
### CONFIGURAR EL SLACK SEGUN LOS PASOS INDICADOS
### CONFIGURAR SSH DEPLOY
### AGREGAR PUBLIC KEY AL SERVIDOR QUE SE CONECTAR ( POR EJEMPLO ACA SE AGREGA ESTE VALOR EN EL SERVIDOR DE demosoft.legalprodata.com)
`vi /root/.ssh/authorized_keys`  
`Copiar valor de public key`  
### CONFIGURAR SSH
### AGREGAR USUARIO Y HOST (AQUI VA EL ROOT DEL SERVIDOR, POR EJEMPO SI SE VA CONECTAR newt.pe A demosoft.legalprodata.com AQUI IRIA root@demosoft.legalprodata.com
`root@demosoft.legalprodata.com`  
`check Transfer bundle?`  
### CONFIGURAR LOS SIGUIENTES COMANDOS EN  EL SHELL
```
cd /home/enterprise_api/
pm2 stop legalprodata-enterprise-api
#ELIMINAR LOS ARCHIVOS ANTERIORES
rm -R /home/enterprise_api/*
#COPIAR TODOS LOS ARCHIVOS DE LA WEB
cp -r /root/jimytac_legalprodata_enterprise_api/* /home/enterprise_api/
#SETEAR VARIABLE DE ENTORNO
#echo 'export NODE_ENV="development"' >> ~/.bashrc
#source ~/.bashrc
cp /home/enterprise_api.env /home/enterprise_api/.env
npm install
npm uninstall -S nodemon
pm2 start legalprodata-enterprise-api-dev.json
#pm2 startup systemd
#pm2 save
```
### SIEMPRE HACERLE UN TEST Y UN DEPLOY PRIMERO ANTES DEL COMMIT

### CREAR CARPETA PARA DASHBOARD
`mkdir /home/dashboard`  
`chmod 777 -R /home/dashboard` 
### INSTALAR ANGULAR GLOBALMENTE
`npm install -g @angular/cli`  
### SELECCIONAR EL PROYECTO EN NODE Y HACER CLICK EN ADD
### SELECCIONAR CUSTOM
### IR A CONGIURE
### EN SETTINGS COPIAR EL PUBLIC KEY EN LA SIGUIENTE RUTA
`https://github.com/jimytac/legalprodata_dashboard/settings/keys` -> Add Deploy Key  
```
Title: LegalProData Dashboard
Key: Copiar valor de public key
Check Allo write Acces
```
### IR A LA SECCION DE PLUGIN Y AGREGAR
`Email Notifier`  
`SSh Deploy`  
`Slack` 
### CONFIGURAR EL SLACK SEGUN LOS PASOS INDICADOS
### CONFIGURAR SSH DEPLOY
### AGREGAR PUBLIC KEY AL SERVIDOR QUE SE CONECTAR ( POR EJEMPLO ACA SE AGREGA ESTE VALOR EN EL SERVIDOR DE demosoft.legalprodata.com)
`vi /root/.ssh/authorized_keys`  
`Copiar valor de public key`  
### CONFIGURAR SSH
### AGREGAR USUARIO Y HOST (AQUI VA EL ROOT DEL SERVIDOR, POR EJEMPO SI SE VA CONECTAR newt.pe A demosoft.legalprodata.com AQUI IRIA root@demosoft.legalprodata.com
`root@demosoft.legalprodata.com`  
`check Transfer bundle?`  
### CONFIGURAR LOS SIGUIENTES COMANDOS EN  EL SHELL
```
rm -R /home/dashboard/
cp -R /root/jimytac_legalprodata_dashboard /home/dashboard
chmod 777 -R /home/dashboard/
cd /home/dashboard/
sudo npm install
rm -R /var/www/demodashboard/*
pm2 stop legalprodata-enterprise-api-dev
pm2 stop legalprodata-seguridad-api-dev
bash /home/liberar.sh
ng build --prod --build-optimizer --base-href --base-href /
cp -R dist/legal-prodata-frontend/* /var/www/demodashboard/ng
cp -R dist/legal-prodata-frontend/* /var/www/demodashboard/
cd /var/www/demodashboard/
#sed -i 's%https://legalprodata.peritum.pe/assets/img/logo.png%https://legalprodata.peritum.pe/dashboard/assets/img/logo.png%g' *.js
#sed -i 's%https://sunat.libellum.pe/sunat/v1%https://demo.libellum.pe/sunat/v1%g' *.js
pm2 start legalprodata-enterprise-api-dev
pm2 start legalprodata-seguridad-api-dev
```
### SIEMPRE HACERLE UN TEST Y UN DEPLOY PRIMERO ANTES DEL COMMIT








